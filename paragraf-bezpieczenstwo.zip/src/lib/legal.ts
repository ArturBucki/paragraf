/**
 * Dane operatora w jednym miejscu — regulamin i polityka prywatności
 * czytają je stąd, żeby nie rozjechały się między dokumentami.
 *
 * UZUPEŁNIJ przed wpuszczeniem prawdziwych użytkowników.
 */
export const LEGAL = {
  operator: "[NAZWA FIRMY / IMIĘ I NAZWISKO, ADRES, NIP]",
  email: "[ADRES E-MAIL DO KONTAKTU]",
  site: "paragraf-seven.vercel.app",
  date: "1 września 2026",
  disclaimer:
    "To rzetelny szkic, nie opinia prawna. Przed startem z prawdziwymi użytkownikami daj oba dokumenty do sprawdzenia prawnikowi — zwłaszcza część o danych osobowych, bo dane o orientacji seksualnej są danymi wrażliwymi (art. 9 RODO) i wymagają wyraźnej zgody.",
} as const;
